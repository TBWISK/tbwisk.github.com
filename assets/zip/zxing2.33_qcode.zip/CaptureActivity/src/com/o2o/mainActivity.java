package com.o2o;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.google.zxing.client.android.CaptureActivity;
import com.google.zxing.client.android.R;

public class mainActivity extends Activity{
	private Button button ;
	private TextView textview;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mainlayout);
		init();
	}
	private void init(){
		button = (Button)findViewById(R.id.button);
		textview = (TextView)findViewById(R.id.textview);
		button.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent=new Intent(mainActivity.this,CaptureActivity.class);  
	            //关键点来了，使用startActivityForResult来启动  
	            startActivityForResult(intent, 100);  
			}
		});
	}
	@Override  
    protected void onActivityResult(int requestCode, int resultCode, Intent data)  
    {  
        //可以根据多个请求代码来作相应的操作  
        if(20==resultCode)  
        {  
            String result=data.getExtras().getString("result");  
            
            textview.setText(result);  
        }  
        super.onActivityResult(requestCode, resultCode, data);  
    }

}
