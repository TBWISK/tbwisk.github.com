#!/bin/bash
NDK=/appdev/ndk/android-ndk-r10e
SYSROOT=$NDK/platforms/android-9/arch-arm/
TOOLCHAIN=$NDK/toolchains/arm-linux-androideabi-4.8/prebuilt/darwin-x86_64
# PREBUILT=../simplefflib
CC=/appdev/ndk/android-ndk-r10e/toolchains/arm-linux-androideabi-4.8/prebuilt/darwin-x86_64/bin
X264_ROOT=/appdev/ndk/android-ndk-r10e/sources/x264-snapshot-20151220-2245/android/include

function build_one
{
./configure \
 --extra-libs=-lgcc \
  --target-os=linux \
  --prefix=$PREFIX \
    --enable-cross-compile \
    --enable-runtime-cpudetect \
    --disable-asm \
    --arch=$CPU \
    --sysroot=$SYSROOT \
    --cc=$CC/arm-linux-androideabi-gcc \
    --cross-prefix=$TOOLCHAIN/bin/arm-linux-androideabi- \
    --disable-stripping \
    --nm=$TOOLCHAIN/bin/arm-linux-androideabi-nm \
    --enable-gpl \
    --enable-libx264 \
    --enable-shared \
    --disable-static \
    --enable-small \
    --disable-ffprobe \
    --disable-ffplay \
    --disable-ffmpeg --disable-ffserver --disable-debug \
    --extra-cflags="-fPIC -DANDROID -D__thumb__ -mthumb -Wfatal-errors -Wno-deprecated -mfloat-abi=softfp -marm -march=armv7-a -I$X264_ROOT" \
    --extra-ldflags=-L/appdev/ndk/android-ndk-r10e/sources/x264-snapshot-20151220-2245/android/lib 
make clean
make 
make install
}
CPU=arm
PREFIX=$(pwd)/android/$CPU
ADDI_CFLAGS="-marm"
build_one