export NDK=/appdev/ndk/android-ndk-r10e
export VERSION=4.8
export PREBUILT=$NDK/toolchains/arm-linux-androideabi-$VERSION/prebuilt
export PLATFORM=$NDK/platforms/android-8/arch-arm
./configure --enable-static \
	--enable-shared \
	--enable-pic \
	--disable-asm \
	--disable-cli \
	--host=arm-linux \
	--cross-prefix=$PREBUILT/darwin-x86_64/bin/arm-linux-androideabi- \
	--sysroot=$PLATFORM \
	--arch="arm"
	--prefix=./android
make && make install


